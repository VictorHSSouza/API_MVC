﻿using System.ComponentModel.DataAnnotations;

namespace Farmacia.API.DTO
{
    public class ClienteDTO
    {
        public int ClienteId { get; set; }

        [Required(ErrorMessage = "Favor colocar um nome para o Cliente")]
        public string? Nome { get; set; }

        [Required]
        public string? Telefone { get; set; }

        [Required(ErrorMessage = "Favor colocar um e-mail")]
        [EmailAddress(ErrorMessage = "Favor digitar um e-mail válido.")]
        public string? Email { get; set; }

        [Required(ErrorMessage = "Favor colocar sua data de nascimento")]
        [Display(Name = "Data de Nascimento")]
        public DateTime DataNascimento { get; set; }
    }
}
