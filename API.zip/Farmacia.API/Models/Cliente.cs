﻿using System.ComponentModel.DataAnnotations;

namespace Farmacia.API.Models
{
    public class Cliente
    {
        [Key]
        public int IdCliente { get; set; }

        [Required]
        public string? Nome { get; set; }

        [Required]
        public string? Telefone { get; set; }

        [Required(ErrorMessage = "Favor colocar um e-mail")]
        [EmailAddress(ErrorMessage = "Favor digitar um e-mail válido.")]
        public string? Email { get; set; }

        [Required]
        [Display(Name = "Data de Nascimento")]
        public DateTime DataNascimento { get; set; }
    }
}
