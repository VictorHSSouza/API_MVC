﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace Farmacia.API.Models
{
    public class Remedio
    {
        [Key]
        public int IdRemedio { get; set; }

        [Required]
        [DisplayName("Nome Remedio")]
        public string NomeRemedio { get; set; }

        [Required]
        [DisplayName("Descrição")]
        public string Descricao { get; set; }

        [Required]
        [Range(0.01, 999.00, ErrorMessage = "Preço deve ficar entre 0.01 até 999.00")]
        public double Preco { get; set; }

        [Required]
        public int Estoque { get; set; }
    }
}
