﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Farmacia.API.Models;

namespace Farmacia.API.DTO
{
    public class RemedioDTO
    {
        public int IdRemedio { get; set; }

        [Required(ErrorMessage = "Favor colocar um nome para o Remédio")]
        [DisplayName("Nome Remedio")]
        public string? NomeRemedio { get; set; }

        [Required(ErrorMessage = "Favor colocar uma descrição")]
        [DisplayName("Descrição")]
        public string? Descricao { get; set; }

        [Required(ErrorMessage = "Favor colocar um preço para o Remédio")]
        [Range(0.01, 999.00, ErrorMessage = "Preço deve ficar entre 0.01 até 999.00")]
        public double Preco { get; set; }

        [Required(ErrorMessage = "Favor colocar o estoque do Remédio")]
        public int Estoque { get; set; }
    }
}
