﻿using Farmacia.API.Models;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Farmacia.API.DTO
{
    public class PedidoDTO
    {
        public int IdPedido { get; set; }

        [Required]
        public DateTime DataHora { get; set; }
        public string? Observacoes { get; set; }
        [Required]
        public int Status { get; set; }

        [Required]
        public int ClienteId { get; set; }
        public Cliente Cliente { get; set; }

        public virtual ICollection<Remedio> Remedios { get; set; }
    }
}
