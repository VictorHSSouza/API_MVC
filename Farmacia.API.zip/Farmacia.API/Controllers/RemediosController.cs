﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Farmacia.API.Data;
using Farmacia.API.Models;

namespace Farmacia.API.Controllers
{
    public class RemediosController : Controller
    {
        private readonly ApplicationDbContext _context;

        public RemediosController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Remedios
        public async Task<IActionResult> Index()
        {
            return View(await _context.Remedios.ToListAsync());
        }

        // GET: Remedios/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var remedio = await _context.Remedios
                .FirstOrDefaultAsync(m => m.IdRemedio == id);
            if (remedio == null)
            {
                return NotFound();
            }

            return View(remedio);
        }

        // GET: Remedios/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Remedios/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("IdRemedio,NomeRemedio,Descricao,Preco,Estoque")] Remedio remedio)
        {
            if (ModelState.IsValid)
            {
                _context.Add(remedio);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(remedio);
        }

        // GET: Remedios/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var remedio = await _context.Remedios.FindAsync(id);
            if (remedio == null)
            {
                return NotFound();
            }
            return View(remedio);
        }

        // POST: Remedios/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("IdRemedio,NomeRemedio,Descricao,Preco,Estoque")] Remedio remedio)
        {
            if (id != remedio.IdRemedio)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(remedio);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!RemedioExists(remedio.IdRemedio))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(remedio);
        }

        // GET: Remedios/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var remedio = await _context.Remedios
                .FirstOrDefaultAsync(m => m.IdRemedio == id);
            if (remedio == null)
            {
                return NotFound();
            }

            return View(remedio);
        }

        // POST: Remedios/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var remedio = await _context.Remedios.FindAsync(id);
            if (remedio != null)
            {
                _context.Remedios.Remove(remedio);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool RemedioExists(int id)
        {
            return _context.Remedios.Any(e => e.IdRemedio == id);
        }
    }
}
